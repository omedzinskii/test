#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

void riffle_once(void *L, int len, int size, void *work){ 
	// L = [1,2,3,4]
	// [1,2] [3,4]
	
	//i = 0, left = L[i*size], right = 3
	
	// work = [ , , , ]
	
	int midpoint = len/2;
	
	void* left = L;
	void* right = L + (midpoint*size);
	
	
	for( int i =0; i< midpoint; i+=1){
		int base = i*2;
		
		int rand_int = rand();
		int n = rand_int % 2;
		
		char a = base*size;
		char b = (base+1)*size;
		
		if (n == 0) {
			memcpy(work+(a),left+(i*size),size);
			memcpy(work+(b),right+(i*size),size);
		} else {
			memcpy(work+(b),left+(i*size),size);
			memcpy(work+(a),right+(i*size),size);
		}

	}
	
	//If odd number of elements, last element will always remain last
	if (len % 2 == 1) {
	
		int final_place = ((len-1)*size);
		memcpy(work + final_place, L + final_place,size);
		
	}
	
	memcpy(L,work,size*len);
	
}

void riffle(void *L, int len, int size, int N) {
			
	// create a workspace 
	void *work = malloc(size*len);
	
	if (work == NULL){
		printf("out of memory");
		exit(1);
	}
	
	//seed random
	srand(time(NULL)); 
	
	//itterativly call riffle_once, up to N times 
	for (int i=0; i< N; i++){
		riffle_once(L,len,size,work);
	}
	
}

/*
int check_shuffle(void *L, int len, int size, int (*cmp)(void *, void *)){

}

float quality(int *numbers, int len) {
	
}


average quality(int N, int shuffles, int trials) {

}

*/