#include "riffle.c"

int main(){
	
	//Array of integers
	int array[] = {1,2,3,4,5,6,7};
	
	//Get size of an element and length of array
	int size = sizeof(array[0]);
	int length = sizeof(array)/sizeof(array[0]);
	
	// Shuffle
	riffle(&array, length, size, 8);
	
	//For each integer in workspace, print it out
	for( int i =0; i< length; i++){
		printf("%d", array[i]);
	};
	printf("\n");
	
	
	//Array of pointers to characters
	char *greek[] = {"alpha", "beta", "gamma", "delta", "epsilon", "zeta","eta", "theta", "iota", "kappa", "lambda", "mu" };
	
	//Get size of a pointer, and number of pointers
	size = sizeof(greek[0]);
	length = sizeof(greek)/sizeof(greek[0]);
	
	//Shuffle pointers
	riffle(greek, length, size, 8);
	
	//Print out chars at each pointer
	for( int i =0; i< length; i++){
		printf("%s\n", (char*)greek[i]);
	};
	
	
}